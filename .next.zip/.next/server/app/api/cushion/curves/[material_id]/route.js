var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/cushion/curves/[material_id]/route.js")
R.c("server/chunks/[root-of-the-server]__380df1b9._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/ce889_server_app_api_cushion_curves_[material_id]_route_actions_13041649.js")
R.m(77090)
module.exports=R.m(77090).exports
