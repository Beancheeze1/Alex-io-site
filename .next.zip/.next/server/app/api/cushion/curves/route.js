var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cushion/curves/route.js")
R.c("server/chunks/[root-of-the-server]__d6dc2979._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_cushion_curves_route_actions_637a03c8.js")
R.m(83774)
module.exports=R.m(83774).exports
