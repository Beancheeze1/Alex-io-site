var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/cushion/curves/export/route.js")
R.c("server/chunks/[root-of-the-server]__6d730cfa._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_cushion_curves_export_route_actions_70a5b54a.js")
R.m(31369)
module.exports=R.m(31369).exports
