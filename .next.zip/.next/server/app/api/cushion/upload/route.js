var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cushion/upload/route.js")
R.c("server/chunks/[root-of-the-server]__2ed41d90._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_cushion_upload_route_actions_b3d240f9.js")
R.m(71289)
module.exports=R.m(71289).exports
