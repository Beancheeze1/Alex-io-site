var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/db/diag/route.js")
R.c("server/chunks/[root-of-the-server]__7055e75d._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_db_diag_route_actions_22ce3416.js")
R.m(51967)
module.exports=R.m(51967).exports
