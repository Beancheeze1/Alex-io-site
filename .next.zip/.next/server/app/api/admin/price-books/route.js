var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/price-books/route.js")
R.c("server/chunks/[root-of-the-server]__90afe44a._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_price-books_route_actions_92c281c6.js")
R.m(11092)
module.exports=R.m(11092).exports
