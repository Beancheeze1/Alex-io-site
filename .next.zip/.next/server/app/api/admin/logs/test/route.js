var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/logs/test/route.js")
R.c("server/chunks/[root-of-the-server]__fc132ebd._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_logs_test_route_actions_7480c2fd.js")
R.m(94054)
module.exports=R.m(94054).exports
