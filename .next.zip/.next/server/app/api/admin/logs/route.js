var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/logs/route.js")
R.c("server/chunks/[root-of-the-server]__3be6b506._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_logs_route_actions_0b185978.js")
R.m(50803)
module.exports=R.m(50803).exports
