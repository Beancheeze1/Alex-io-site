var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/responder/route.js")
R.c("server/chunks/[root-of-the-server]__20a9e130._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_responder_route_actions_648b873c.js")
R.m(96764)
module.exports=R.m(96764).exports
