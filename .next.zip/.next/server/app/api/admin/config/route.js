var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/config/route.js")
R.c("server/chunks/[root-of-the-server]__c4caf7e3._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_config_route_actions_4f206dcd.js")
R.m(54313)
module.exports=R.m(54313).exports
