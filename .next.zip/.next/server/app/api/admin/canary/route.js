var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/canary/route.js")
R.c("server/chunks/[root-of-the-server]__6b4acfa0._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_canary_route_actions_5d531765.js")
R.m(7016)
module.exports=R.m(7016).exports
