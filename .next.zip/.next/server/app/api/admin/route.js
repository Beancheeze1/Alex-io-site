var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/route.js")
R.c("server/chunks/[root-of-the-server]__7d8dd1f6._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_route_actions_ef3ab472.js")
R.m(62569)
module.exports=R.m(62569).exports
