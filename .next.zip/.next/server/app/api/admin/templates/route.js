var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/templates/route.js")
R.c("server/chunks/[root-of-the-server]__dc9030ab._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_templates_route_actions_ec109874.js")
R.m(11952)
module.exports=R.m(11952).exports
