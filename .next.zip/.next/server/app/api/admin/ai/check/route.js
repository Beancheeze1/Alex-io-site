var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/ai/check/route.js")
R.c("server/chunks/[root-of-the-server]__9473ec1b._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_ai_check_route_actions_d3f5154a.js")
R.m(24054)
module.exports=R.m(24054).exports
