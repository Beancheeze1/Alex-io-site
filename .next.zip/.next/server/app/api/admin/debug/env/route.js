var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/debug/env/route.js")
R.c("server/chunks/[root-of-the-server]__67950f87._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_debug_env_route_actions_8406072f.js")
R.m(99154)
module.exports=R.m(99154).exports
