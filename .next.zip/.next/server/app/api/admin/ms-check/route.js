var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/ms-check/route.js")
R.c("server/chunks/[root-of-the-server]__b4921607._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_ms-check_route_actions_d08f37a0.js")
R.m(57590)
module.exports=R.m(57590).exports
