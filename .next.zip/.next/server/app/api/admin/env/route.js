var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/env/route.js")
R.c("server/chunks/[root-of-the-server]__cc643e58._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_env_route_actions_620a53f2.js")
R.m(39634)
module.exports=R.m(39634).exports
