var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/refresh/route.js")
R.c("server/chunks/[root-of-the-server]__0dd603ad._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_refresh_route_actions_dc62b98a.js")
R.m(47132)
module.exports=R.m(47132).exports
