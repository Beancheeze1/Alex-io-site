var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/settings/route.js")
R.c("server/chunks/[root-of-the-server]__2d7be125._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_settings_route_actions_fd998405.js")
R.m(73456)
module.exports=R.m(73456).exports
