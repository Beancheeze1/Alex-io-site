var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/whoami/route.js")
R.c("server/chunks/[root-of-the-server]__1445596d._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_whoami_route_actions_e07b0157.js")
R.m(30138)
module.exports=R.m(30138).exports
