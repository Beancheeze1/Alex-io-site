var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/kv/route.js")
R.c("server/chunks/[root-of-the-server]__1477834e._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_kv_route_actions_453553be.js")
R.m(91351)
module.exports=R.m(91351).exports
