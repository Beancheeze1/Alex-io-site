var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/log-ping/route.js")
R.c("server/chunks/[root-of-the-server]__eb5497d5._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_log-ping_route_actions_76149871.js")
R.m(53252)
module.exports=R.m(53252).exports
