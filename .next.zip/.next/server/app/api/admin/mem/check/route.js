var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/mem/check/route.js")
R.c("server/chunks/[root-of-the-server]__fd6c62c7._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_mem_check_route_actions_064a18c5.js")
R.m(59762)
module.exports=R.m(59762).exports
