var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/mem/route.js")
R.c("server/chunks/[root-of-the-server]__8d68029d._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_mem_route_actions_0b855f06.js")
R.m(96789)
module.exports=R.m(96789).exports
