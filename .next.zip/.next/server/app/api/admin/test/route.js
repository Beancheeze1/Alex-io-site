var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/test/route.js")
R.c("server/chunks/[root-of-the-server]__0028aa92._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_test_route_actions_fef6f6ce.js")
R.m(86054)
module.exports=R.m(86054).exports
