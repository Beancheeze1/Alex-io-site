var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/db/health/route.js")
R.c("server/chunks/[root-of-the-server]__aab8dfff._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_db_health_route_actions_585b1123.js")
R.m(73803)
module.exports=R.m(73803).exports
