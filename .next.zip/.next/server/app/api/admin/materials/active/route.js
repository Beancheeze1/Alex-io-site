var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/materials/active/route.js")
R.c("server/chunks/[root-of-the-server]__bf0e026c._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_materials_active_route_actions_26bfdaa5.js")
R.m(72108)
module.exports=R.m(72108).exports
