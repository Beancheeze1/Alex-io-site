var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cushion-curves/route.js")
R.c("server/chunks/[root-of-the-server]__b924fb9f._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_cushion-curves_route_actions_ab484e0e.js")
R.m(63174)
module.exports=R.m(63174).exports
