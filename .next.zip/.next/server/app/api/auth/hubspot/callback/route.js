var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/hubspot/callback/route.js")
R.c("server/chunks/[root-of-the-server]__2f3c5bf1._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_hubspot_callback_route_actions_11c3340d.js")
R.m(19629)
module.exports=R.m(19629).exports
