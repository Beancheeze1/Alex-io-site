var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/hubspot/route.js")
R.c("server/chunks/[root-of-the-server]__8df8eba6._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_hubspot_route_actions_7aaf98e1.js")
R.m(22932)
module.exports=R.m(22932).exports
