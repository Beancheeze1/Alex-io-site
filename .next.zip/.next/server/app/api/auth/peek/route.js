var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/peek/route.js")
R.c("server/chunks/[root-of-the-server]__47ca9a13._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_fa90cebf.js")
R.c("server/chunks/_next-internal_server_app_api_auth_peek_route_actions_51a3609c.js")
R.m(29447)
module.exports=R.m(29447).exports
