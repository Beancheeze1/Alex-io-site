var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/me/route.js")
R.c("server/chunks/[root-of-the-server]__7c3c5d08._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_d3c410a6._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_me_route_actions_97ac7615.js")
R.m(84843)
module.exports=R.m(84843).exports
