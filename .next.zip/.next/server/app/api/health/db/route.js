var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/health/db/route.js")
R.c("server/chunks/[root-of-the-server]__b20c93fa._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_health_db_route_actions_a0572fd4.js")
R.m(7309)
module.exports=R.m(7309).exports
