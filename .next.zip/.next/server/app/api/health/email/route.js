var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/health/email/route.js")
R.c("server/chunks/[root-of-the-server]__f0da77ed._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_health_email_route_actions_ed1d654e.js")
R.m(40613)
module.exports=R.m(40613).exports
