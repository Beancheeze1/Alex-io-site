var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/quote/route.js")
R.c("server/chunks/[root-of-the-server]__abd5ea28._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_quote_route_actions_6e39c423.js")
R.m(12812)
module.exports=R.m(12812).exports
