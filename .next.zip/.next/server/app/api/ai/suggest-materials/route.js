var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/suggest-materials/route.js")
R.c("server/chunks/[root-of-the-server]__a6b8ef35._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_suggest-materials_route_actions_359e8a09.js")
R.m(37514)
module.exports=R.m(37514).exports
