var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/cushion/recommend/route.js")
R.c("server/chunks/[root-of-the-server]__446bed3c._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_cushion_recommend_route_actions_7d086df3.js")
R.m(30143)
module.exports=R.m(30143).exports
