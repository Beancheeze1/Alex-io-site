var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/orchestrate/route.js")
R.c("server/chunks/[root-of-the-server]__2d616d8c._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_b0bbfcf4._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_orchestrate_route_actions_66909707.js")
R.m(74952)
module.exports=R.m(74952).exports
