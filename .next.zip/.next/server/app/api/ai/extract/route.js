var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/extract/route.js")
R.c("server/chunks/[root-of-the-server]__9ea2d5f0._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_extract_route_actions_71399642.js")
R.m(19889)
module.exports=R.m(19889).exports
