var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/respond/route.js")
R.c("server/chunks/[root-of-the-server]__efb7a6b4._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_respond_route_actions_3516ce6d.js")
R.m(9907)
module.exports=R.m(9907).exports
