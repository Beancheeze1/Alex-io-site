var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/price/route.js")
R.c("server/chunks/[root-of-the-server]__9958c5a4._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_price_route_actions_49b1b5b0.js")
R.m(59742)
module.exports=R.m(59742).exports
