var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/foam-advisor/recommend/route.js")
R.c("server/chunks/[root-of-the-server]__ad4d8147._.js")
R.c("server/chunks/[root-of-the-server]__db2b3a24._.js")
R.c("server/chunks/_next-internal_server_app_api_foam-advisor_recommend_route_actions_88bc1dc0.js")
R.m(70756)
module.exports=R.m(70756).exports
