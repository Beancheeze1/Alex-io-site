// postcss.config.mjs
export default {
  plugins: {
    '@tailwindcss/postcss': {},
    'postcss-import': {}, // add this
  },
};
